from payment_methods.credit_card import CreditCard
from payment_methods.upi import Upi
class OnlineStore:
    def __init__(self,paymentmethod):
        self.payment_method=paymentmethod
    def process(self,amount):
        print("Processing Transcation")
        self.payment_method.authenticate()
        self.payment_method.pay(amount)
        print("Transction completed")
payment1=CreditCard() #Credit Card instance
payment2=Upi()  #upi instace
order1=OnlineStore(payment1)        
order1.process(5000)