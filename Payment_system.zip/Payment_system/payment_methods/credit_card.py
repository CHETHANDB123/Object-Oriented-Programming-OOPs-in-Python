from api.payment_api import PaymentAPI
from random import randint
class CreditCard(PaymentAPI):
    def authenticate(self):
        otp=randint(100,999)
        print(f"Credit Card OTP Verified{otp}")
        print("Credit Authentication Done")

    def pay(self,amount):
        transid=randint(10000,99999)
        print(f"Trannscation ID is{transid}")
        print(f"Paid{amount}Using Credit Card")
