from api.payment_api import PaymentAPI
from random import randint
class Upi(PaymentAPI):
    def authenticate(self):
        Pin=randint(100,999)
        print(f"UPI PIN is Verified{Pin}")
        print("UPI Authentication Done")

    def pay(self,amount):
        transid=randint(10000,99999)
        print(f"Trannscation ID is{transid}")
        print(f"Paid{amount}Using UPI")
